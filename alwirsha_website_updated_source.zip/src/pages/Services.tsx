import React from 'react';

const Services: React.FC = () => {
  return (
    <div className="min-h-screen py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">خدماتنا</h1>
        
        <div className="max-w-4xl mx-auto">
          <p className="text-lg text-gray-700 mb-8 text-center">
            تقدم الورشة الهندسية مجموعة شاملة من خدمات الصيانة والإصلاح لجميع أنواع أجهزة التبريد والتكييف
          </p>
          
          {/* Air Conditioners Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">إصلاح وصيانة المكيفات والسبلت</h2>
            <div className="border-b border-gray-200 pb-4 mb-4">
              <h3 className="text-xl font-semibold mb-2">المكيفات المنزلية</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>تنظيف وصيانة دورية</li>
                <li>إصلاح الأعطال وتغيير القطع التالفة</li>
                <li>شحن غاز التبريد</li>
                <li>إصلاح تسريبات الغاز</li>
                <li>استبدال الضواغط (الكمبريسرات)</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">السبلت</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>تركيب وحدات جديدة</li>
                <li>صيانة دورية وتنظيف</li>
                <li>إصلاح الدوائر الكهربائية</li>
                <li>استبدال المكثفات والمحركات</li>
              </ul>
            </div>
          </div>
          
          {/* Central Systems Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">المنظومات المركزية ومنظومات الـ VRF</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>تركيب وتشغيل المنظومات المركزية</li>
              <li>صيانة دورية وفحص شامل</li>
              <li>إصلاح الأعطال المعقدة</li>
              <li>تحسين كفاءة الطاقة</li>
              <li>استبدال القطع التالفة</li>
              <li>برمجة وضبط أنظمة التحكم</li>
            </ul>
          </div>
          
          {/* Refrigerators Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">إصلاح الثلاجات والمجمدات</h2>
            <div className="border-b border-gray-200 pb-4 mb-4">
              <h3 className="text-xl font-semibold mb-2">الثلاجات المنزلية</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>إصلاح نظام التبريد</li>
                <li>استبدال الضواغط والمكثفات</li>
                <li>إصلاح تسريبات الغاز</li>
                <li>صيانة الدوائر الكهربائية</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">العارضات التجارية</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                <li>صيانة دورية للعارضات التجارية</li>
                <li>إصلاح أنظمة التبريد</li>
                <li>استبدال القطع التالفة</li>
                <li>ضبط درجات الحرارة</li>
              </ul>
            </div>
          </div>
          
          {/* Cold Rooms Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">غرف التبريد والتجميد</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>تركيب وتجهيز غرف التبريد والتجميد</li>
              <li>صيانة دورية وفحص شامل</li>
              <li>إصلاح أنظمة التبريد</li>
              <li>ضبط وتحسين كفاءة الطاقة</li>
              <li>إصلاح العوازل والأبواب</li>
              <li>صيانة أنظمة التحكم في درجات الحرارة</li>
            </ul>
          </div>
          
          {/* Call to Action */}
          <div className="mt-12 text-center">
            <p className="text-lg mb-6">للحصول على خدماتنا أو الاستفسار عن أي خدمة، يرجى التواصل معنا</p>
            <a href="/contact" className="bg-blue-600 text-white hover:bg-blue-700 font-bold py-3 px-8 rounded-full transition duration-300">اتصل بنا الآن</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
