import React from 'react';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-cyan-500 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">الورشة الهندسية</h1>
          <p className="text-xl md:text-2xl mb-8">خبراء في إصلاح وصيانة أجهزة التبريد والتكييف</p>
          <a href="/contact" className="bg-white text-blue-600 hover:bg-blue-100 font-bold py-3 px-8 rounded-full text-lg transition duration-300">تواصل معنا</a>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">لماذا تختار الورشة الهندسية؟</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-blue-600 text-4xl mb-4">
                <i className="fas fa-tools"></i>
              </div>
              <h3 className="text-xl font-bold mb-3">خبرة فنية عالية</h3>
              <p className="text-gray-600">فريق من الفنيين المهرة ذوي الخبرة في إصلاح جميع أنواع أجهزة التبريد</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-blue-600 text-4xl mb-4">
                <i className="fas fa-bolt"></i>
              </div>
              <h3 className="text-xl font-bold mb-3">خدمة سريعة</h3>
              <p className="text-gray-600">نقدم خدمات صيانة سريعة وفعالة لتقليل فترة التعطل</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-blue-600 text-4xl mb-4">
                <i className="fas fa-cog"></i>
              </div>
              <h3 className="text-xl font-bold mb-3">قطع غيار أصلية</h3>
              <p className="text-gray-600">نستخدم قطع غيار عالية الجودة لضمان أداء مثالي وعمر أطول للأجهزة</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">خدماتنا</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
              <h3 className="text-xl font-bold mb-3 text-blue-700">إصلاح وصيانة المكيفات</h3>
              <p className="mb-4">نقدم خدمات إصلاح وصيانة لجميع أنواع المكيفات والسبلت المنزلية</p>
              <a href="/services" className="text-blue-600 hover:text-blue-800 font-medium">المزيد من التفاصيل &larr;</a>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
              <h3 className="text-xl font-bold mb-3 text-blue-700">صيانة المنظومات المركزية</h3>
              <p className="mb-4">خدمات متخصصة للمنظومات المركزية ومنظومات الـ VRF</p>
              <a href="/services" className="text-blue-600 hover:text-blue-800 font-medium">المزيد من التفاصيل &larr;</a>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
              <h3 className="text-xl font-bold mb-3 text-blue-700">إصلاح الثلاجات والمجمدات</h3>
              <p className="mb-4">خدمات صيانة وإصلاح للثلاجات والمجمدات المنزلية والتجارية</p>
              <a href="/services" className="text-blue-600 hover:text-blue-800 font-medium">المزيد من التفاصيل &larr;</a>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
              <h3 className="text-xl font-bold mb-3 text-blue-700">صيانة غرف التبريد</h3>
              <p className="mb-4">خدمات متخصصة لصيانة وإصلاح غرف التبريد والتجميد</p>
              <a href="/services" className="text-blue-600 hover:text-blue-800 font-medium">المزيد من التفاصيل &larr;</a>
            </div>
          </div>
          
          <div className="text-center mt-10">
            <a href="/services" className="bg-blue-600 text-white hover:bg-blue-700 font-bold py-2 px-6 rounded-full transition duration-300">عرض جميع الخدمات</a>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">هل تحتاج إلى خدمات صيانة؟</h2>
          <p className="text-xl mb-8">تواصل معنا اليوم للحصول على خدمة احترافية وسريعة</p>
          <a href="/contact" className="bg-white text-blue-600 hover:bg-blue-100 font-bold py-3 px-8 rounded-full text-lg transition duration-300">اتصل بنا الآن</a>
        </div>
      </section>
    </div>
  );
};

export default Home;
