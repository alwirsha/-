import React from 'react';

const SpareParts: React.FC = () => {
  return (
    <div className="min-h-screen py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">قطع الغيار</h1>
        
        <div className="max-w-4xl mx-auto">
          <p className="text-lg text-gray-700 mb-8 text-center">
            توفر الورشة الهندسية جميع أنواع قطع الغيار الأصلية والعالية الجودة لأجهزة التبريد والتكييف
          </p>
          
          {/* Compressors Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">الضواغط (الكمبريسرات)</h2>
            <p className="mb-4 text-gray-700">
              نوفر مجموعة واسعة من الضواغط لجميع أنواع أجهزة التبريد والتكييف، بما في ذلك:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>ضواغط للمكيفات المنزلية</li>
              <li>ضواغط للسبلت</li>
              <li>ضواغط للمنظومات المركزية</li>
              <li>ضواغط للثلاجات والمجمدات</li>
              <li>ضواغط لغرف التبريد</li>
            </ul>
            <p className="mt-4 text-gray-700">
              نتعامل مع أفضل العلامات التجارية العالمية لضمان الجودة والأداء المثالي.
            </p>
          </div>
          
          {/* Capacitors Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">المكثفات</h2>
            <p className="mb-4 text-gray-700">
              نوفر مكثفات عالية الجودة لمختلف أنواع أجهزة التبريد:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>مكثفات تشغيل</li>
              <li>مكثفات بدء التشغيل</li>
              <li>مكثفات مزدوجة</li>
              <li>مكثفات للمحركات المختلفة</li>
            </ul>
            <p className="mt-4 text-gray-700">
              جميع المكثفات التي نوفرها مضمونة وذات عمر تشغيلي طويل.
            </p>
          </div>
          
          {/* Refrigerant Gas Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">غاز التبريد</h2>
            <p className="mb-4 text-gray-700">
              نوفر جميع أنواع غازات التبريد المستخدمة في مختلف الأجهزة:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>R-22</li>
              <li>R-410A</li>
              <li>R-134a</li>
              <li>R-404A</li>
              <li>R-407C</li>
              <li>وأنواع أخرى من غازات التبريد الصديقة للبيئة</li>
            </ul>
          </div>
          
          {/* Motors and Fans Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">محركات وريش التبريد (الفانات)</h2>
            <p className="mb-4 text-gray-700">
              نوفر مجموعة متنوعة من المحركات وريش التبريد:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>محركات للوحدات الداخلية</li>
              <li>محركات للوحدات الخارجية</li>
              <li>ريش تبريد بمختلف الأحجام</li>
              <li>محركات لمراوح التبريد</li>
              <li>محركات للثلاجات والمجمدات</li>
            </ul>
            <p className="mt-4 text-gray-700">
              جميع المحركات وريش التبريد التي نوفرها ذات جودة عالية وكفاءة ممتازة.
            </p>
          </div>
          
          {/* Other Parts Section */}
          <div className="bg-white rounded-lg shadow-md p-6 mt-8">
            <h2 className="text-2xl font-bold text-blue-700 mb-4">قطع غيار أخرى</h2>
            <p className="mb-4 text-gray-700">
              بالإضافة إلى القطع الرئيسية، نوفر أيضاً:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>لوحات تحكم إلكترونية</li>
              <li>ثيرموستات</li>
              <li>صمامات التمدد</li>
              <li>مرشحات (فلاتر)</li>
              <li>مجففات</li>
              <li>أنابيب نحاسية</li>
              <li>عوازل حرارية</li>
              <li>وغيرها من القطع اللازمة لأعمال الصيانة والإصلاح</li>
            </ul>
          </div>
          
          {/* Call to Action */}
          <div className="mt-12 text-center">
            <p className="text-lg mb-6">للاستفسار عن توفر قطع الغيار أو أسعارها، يرجى التواصل معنا</p>
            <a href="/contact" className="bg-blue-600 text-white hover:bg-blue-700 font-bold py-3 px-8 rounded-full transition duration-300">اتصل بنا الآن</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpareParts;
