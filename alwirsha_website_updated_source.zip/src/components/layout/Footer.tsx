import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="mb-6 md:mb-0">
            <h2 className="text-2xl font-bold mb-4">الورشة الهندسية</h2>
            <p className="text-gray-300">
              متخصصون في إصلاح وصيانة جميع أنواع أجهزة التبريد والتكييف
            </p>
          </div>
          
          <div className="mb-6 md:mb-0">
            <h3 className="text-xl font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li><a href="/" className="hover:text-blue-400">الرئيسية</a></li>
              <li><a href="/services" className="hover:text-blue-400">الخدمات</a></li>
              <li><a href="/spare-parts" className="hover:text-blue-400">قطع الغيار</a></li>
              <li><a href="/contact" className="hover:text-blue-400">اتصل بنا</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">تواصل معنا</h3>
            <p className="mb-2">
              <span className="font-bold">البريد الإلكتروني:</span> alwirshaalhandasia@gmail.com
            </p>
            <p className="mb-2">
              <span className="font-bold">رقم الهاتف:</span> 07710174485
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 text-center">
          <p>&copy; {new Date().getFullYear()} الورشة الهندسية - جميع الحقوق محفوظة</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
