import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold">الورشة الهندسية</Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={toggleMenu}
              className="focus:outline-none"
            >
              <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
                {isMenuOpen ? (
                  <path fillRule="evenodd" d="M18.278 16.864a1 1 0 0 1-1.414 1.414l-4.829-4.828-4.828 4.828a1 1 0 0 1-1.414-1.414l4.828-4.829-4.828-4.828a1 1 0 0 1 1.414-1.414l4.829 4.828 4.828-4.828a1 1 0 1 1 1.414 1.414l-4.828 4.829 4.828 4.828z" />
                ) : (
                  <path fillRule="evenodd" d="M4 5h16a1 1 0 0 1 0 2H4a1 1 0 1 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2z" />
                )}
              </svg>
            </button>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-4 items-center">
            <Link to="/" className="px-3 py-2 hover:bg-blue-700 rounded">الرئيسية</Link>
            <Link to="/services" className="px-3 py-2 hover:bg-blue-700 rounded">الخدمات</Link>
            <Link to="/spare-parts" className="px-3 py-2 hover:bg-blue-700 rounded">قطع الغيار</Link>
            <Link to="/contact" className="px-3 py-2 hover:bg-blue-700 rounded">اتصل بنا</Link>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="flex flex-col space-y-2 pb-4">
              <Link to="/" className="px-3 py-2 hover:bg-blue-700 rounded text-center" onClick={toggleMenu}>الرئيسية</Link>
              <Link to="/services" className="px-3 py-2 hover:bg-blue-700 rounded text-center" onClick={toggleMenu}>الخدمات</Link>
              <Link to="/spare-parts" className="px-3 py-2 hover:bg-blue-700 rounded text-center" onClick={toggleMenu}>قطع الغيار</Link>
              <Link to="/contact" className="px-3 py-2 hover:bg-blue-700 rounded text-center" onClick={toggleMenu}>اتصل بنا</Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
